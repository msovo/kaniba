function loginUser(){
    var username=$("#username").val();
    var password=$("#password").val();
    $.ajax({
        url:`https://kanibaapp.azurewebsites.net/BackEnd/Login?UserID=${username}&Password=${password}`,
        type: 'GET',
        datatype: 'json',
        cache: false,
        success: function(data) {
            navigatetoHome(data);
        }
      });


}


function navigatetoHome(res){

    if(res.Success==true){
        sessionStorage.setItem("UserID",res.UserID);
        sessionStorage.setItem("SessionToken",res.SessionToken);
        sessionStorage.setItem("UserProfileImage",res.UserProfileImage);
        sessionStorage.setItem("team",JSON.stringify(res.Team));
        sessionStorage.setItem("FullName",res.FullName);
        sessionStorage.setItem("UserType",res.UserType);

        window.location.href = 'index.html';

    }
}
