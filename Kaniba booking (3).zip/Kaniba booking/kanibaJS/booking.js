
editBooking=`<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
<div class="product-payment-inner-st">
    <ul id="myTabedu1" class="tab-review-design">
        <li class="active"><a href="#description">Courses Details</a></li>
        <li><a href="#reviews"> Account Information</a></li>
        <li><a href="#INFORMATION">Social Information</a></li>
    </ul>
    <div id="myTabContent" class="tab-content custom-product-edit">
        <div class="product-tab-list tab-pane fade active in" id="description">
            <div class="row">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <div class="review-content-section">
                        <div id="dropzone1" class="pro-ad addcoursepro">
                            <form action="#" class="dropzone dropzone-custom needsclick add-professors dz-clickable" id="demo1-upload">
                                <div class="row">
                                    <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                                        <div class="form-group">
                                            <input name="number" type="text" class="form-control" placeholder="Course Name" value="Apps Development">
                                        </div>
                                        <div class="form-group">
                                            <input type="text" class="form-control" placeholder="Course Start Date" value="12/10/2017">
                                        </div>
                                        <div class="form-group">
                                            <input type="text" class="form-control" placeholder="Course Duration" value="6 Months">
                                        </div>
                                        <div class="form-group">
                                            <input type="text" class="form-control" placeholder="Course Price" value="$400">
                                        </div>
                                        <div class="form-group alert-up-pd">
                                            <div class="dz-message needsclick download-custom">
                                                <i class="fa fa-download edudropnone" aria-hidden="true"></i>
                                                <h2 class="edudropnone">Drop image here or click to upload.</h2>
                                                <p class="edudropnone"><span class="note needsclick">(This is just a demo dropzone. Selected image is <strong>not</strong> actually uploaded.)</span>
                                                </p>
                                                <input name="imageico" class="hd-pro-img" type="text">
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                                        <div class="form-group res-mg-t-15">
                                            <input type="text" class="form-control" placeholder="Department" value="CSE">
                                        </div>
                                        <div class="form-group edit-ta-resize">
                                            <textarea name="description">Lorem ipsum dolor sit amet of, consectetur adipiscing elitable. Vestibulum tincidunt est vitae ultrices accumsan.</textarea>
                                        </div>
                                        <div class="form-group">
                                            <input type="text" class="form-control" placeholder="Course Professor" value="Selima sha">
                                        </div>
                                        <div class="form-group">
                                            <input type="text" class="form-control" placeholder="Year" value="1 Year">
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-lg-12">
                                        <div class="payment-adress">
                                            <button type="submit" class="btn btn-primary waves-effect waves-light">Submit</button>
                                        </div>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="product-tab-list tab-pane fade" id="reviews">
            <div class="row">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <div class="review-content-section">
                        <div class="row">
                            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                                <div class="devit-card-custom">
                                    <div class="form-group">
                                        <input type="text" class="form-control" placeholder="Email">
                                    </div>
                                    <div class="form-group">
                                        <input type="number" class="form-control" placeholder="Phone">
                                    </div>
                                    <div class="form-group">
                                        <input type="password" class="form-control" placeholder="Password">
                                    </div>
                                    <div class="form-group">
                                        <input type="password" class="form-control" placeholder="Confirm Password">
                                    </div>
                                    <a href="#!" class="btn btn-primary waves-effect waves-light">Submit</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="product-tab-list tab-pane fade" id="INFORMATION">
            <div class="row">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <div class="review-content-section">
                        <div class="row">
                            <div class="col-lg-12">
                                <div class="devit-card-custom">
                                    <div class="form-group">
                                        <input type="url" class="form-control" placeholder="Facebook URL">
                                    </div>
                                    <div class="form-group">
                                        <input type="url" class="form-control" placeholder="Twitter URL">
                                    </div>
                                    <div class="form-group">
                                        <input type="url" class="form-control" placeholder="Google Plus">
                                    </div>
                                    <div class="form-group">
                                        <input type="url" class="form-control" placeholder="Linkedin URL">
                                    </div>
                                    <button type="submit" class="btn btn-primary waves-effect waves-light">Submit</button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
</div>`

BookingInfomation=`<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
<div class="blog-details-inner">
    <div class="row">
        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
            <div class="latest-blog-single blog-single-full-view">
                <div class="blog-image">
                    <a href="#"><img src="img/blog-details/1.jpg" alt="">
                        </a>
                    <div class="blog-date">
                        <p><span class="blog-day">20</span> May</p>
                    </div>
                </div>
                <div class="blog-details blog-sig-details">
                    <div class="details-blog-dt blog-sig-details-dt courses-info mobile-sm-d-n">
                        <span><a href="#"><i class="fa fa-user"></i> <b>Course Name:</b> Web Development</a></span>
                        <span><a href="#"><i class="fa fa-heart"></i> <b>Course Price:</b> $3000</a></span>
                        <span><a href="#"><i class="fa fa-comments-o"></i> <b>Professor Name:</b> Alva Adition</a></span>
                    </div>
                    <h1><a class="blog-ht" href="#">Courses Info Dummy Title</a></h1>
                    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur.</p>
                    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum. Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo.</p>
                    <p>Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem.</p>
                    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad im veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip</p>
                </div>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
            <div class="comment-head">
                <h3>Comments</h3>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
            <div class="user-comment">
                <img src="img/contact/1.jpg" alt="">
                <div class="comment-details">
                    <h4>Jonathan Doe 2015 15 July <span class="comment-replay">Replay</span></h4>
                    <p>Shabby chic selfies pickled Tumblr letterpress iPhone. Wolf vegan retro selvage literally <span class="mobile-sm-d-n">Wes Anderson ethical four loko. Meggings blog chambray tofu pour-over. Pour-over Tumblr keffiyeh, cornhole whatever cardigan Tonx lomo.Shabby.</span></p>
                </div>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
            <div class="user-comment admin-comment">
                <img src="img/contact/2.jpg" alt="">
                <div class="comment-details">
                    <h4>Jonathan Doe 2015 15 July <span class="comment-replay">Replay</span></h4>
                    <p>Shabby chic selfies pickled Tumblr letterpress iPhone. Wolf vegan retro selvage literally <span class="mobile-sm-d-n">Wes Anderson ethical four loko. Meggings blog chambray tofu pour-over. Pour-over Tumblr keffiyeh, cornhole whatever cardigan
                        Tonx lomo.Shabby.</span></p>
                </div>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
            <div class="user-comment user-coment2">
                <img src="img/contact/3.jpg" alt="">
                <div class="comment-details">
                    <h4>Jonathan Doe 2015 15 July <span class="comment-replay">Replay</span></h4>
                    <p>Shabby chic selfies pickled Tumblr letterpress iPhone. Wolf vegan retro selvage literally Wes Anderson <span class="mobile-sm-d-n">ethical four loko. Meggings blog chambray tofu pour-over. Pour-over Tumblr keffiyeh, cornhole whatever cardigan Tonx lomo.Shabby.</span></p>
                </div>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
            <div class="lead-head">
                <h3>Leave A Comment</h3>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="coment-area">
            <form id="comment" action="#" class="comment" novalidate="novalidate">
                <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12 blog-res-mg-bt">
                    <div class="form-group">
                        <input name="name" class="responsive-mg-b-10" type="text" placeholder="Name">
                    </div>
                </div>
                <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                    <div class="form-group">
                        <input name="email" type="text" placeholder="Email">
                    </div>
                </div>
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <div class="form-group">
                        <textarea name="message" cols="30" rows="10" placeholder="Message"></textarea>
                    </div>
                    <div class="payment-adress comment-stn">
                        <button type="submit" class="btn btn-primary waves-effect waves-light">Send</button>
                    </div>
                </div>
            </form>
        </div>
    </div>
</div>
</div>`



function CraeteBooking(){

    var output=`<div class="single-pro-review-area mt-t-30 mg-b-15" >
    <div class="container-fluid">
        <div class="row" >
            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                <div class="product-payment-inner-st">
                    <ul id="myTabedu1" class="tab-review-design">
                        <li class="ActiveTab" id="actEmployee"  ><a  onclick="callInputFunc('Employee')"  href="#">Employee Infomation</a></li>
                        <li class="ActiveTab" id="actBookingTypes" ><a  onclick="callInputFunc('BookingTypes')"  href="#"> Booking type</a></li>
                        <li class="ActiveTab" id="actDates" ><a  onclick="callInputFunc('Dates')"  href="#">Booking dates</a></li>
                        <li class="ActiveTab" id="actSupplier" ><a   onclick="callInputFunc('Supplier')" href="#">Supplier infomation</a></li>
    
                    </ul>
    
                    <div id="myTabContent" class="tab-content custom-product-edit">
                    <div class="product-tab-list tab-pane fade active in" id="description">
                        <div class="row" id="PutbookingImage">
                            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                                <span id='inputFromOutput'></span>
                                <div class="row">
                            <div class="col-lg-12">
                            <div class="payment-adress">
                                <button type="buttton" onclick = "postbooking()" class="btn btn-primary waves-effect waves-light">Submit booking</button>
                            </div>
                         </div>
                          </div>
                            </div>
                        </div>
                    </div>
    
    
                </div>
                </div>
            </div>
        </div>
    </div>
    </div>`


    $("#calenderViewHtml").slideUp()
    $("#HTML_Loader").html('')
    $("#HTML_Loader").html(output)
    
    createInput(inputsEmployee,"Employee")
    createInput(InputBookingType,"BookingTypes")
    createInput(inputSupplierDetails,"Supplier")
    createInput(inputBookingdates,"Dates")
}




function Listbookings(){
var data=globaldata.Dt;


var output=''
for(var i=0;i<data.length;i++){
     output+=`<tr>
    <td>${i}</td>
    <td>${data[i].RouteCode}</td>
    <td>
    ${data[i].Name}   ${data[i].Surname}
    </td>
    <td> ${data[i].CreationDate}</td>

    <td style="overflow-wrap: break-word;">${data[i].SpecificationOfTheProject}</td>
    <td>${data[i].CityTown}</td>
    <td style="background-color:${createColorFirStatuys(data[i].Status)}">${data[i].Description}</td>
    <td>${data[i]["Total payable inc VAT"]}</td>
    <td>${data[i]["No of Nights"]}</td>
    <td>${Checkpaid(data[i]["Amount paid"])}</td>


    <td>
        <button data-toggle="tooltip" title="Edit" onclick="BookingDetails(${i})" class="pd-setting-ed"><i class="fa fa-pencil-square-o" aria-hidden="true"></i></button>
        <button data-toggle="tooltip" title="Trash" class="pd-setting-ed"><i class="fa fa-trash-o" aria-hidden="true"></i></button>
        <input type="Checkbox" data-toggle="tooltip" title="Check" id="CheckFor${data[i].ID}"/>

    </td>
</tr>`
}

var GetinputBookingdates=[  
    "FCheck in date",
    "FCheck out date",
    "FCompletionDate",
    "CreationDate"
    ]
    var filterbtn=''
    for(var x =0; x<GetinputBookingdates.length; x++){
        GetinputBookingdates[x]=GetinputBookingdates[x].replaceAll(" ","_")
        filterbtn+= `<label class='filterlabel' for='F${GetinputBookingdates[x]}'> ${GetinputBookingdates[x]} </label> <input class="inputdateForm" type='date' id='${GetinputBookingdates[x]}' onchange="filterFuc('${GetinputBookingdates[x]}')" />`
    }

    filterbtn+=createselectForStatus()

    BookingList=`<div class="product-status mg-b-15">
    <div class="container-fluid">
        <div class="row">
            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                <div class="product-status-wrap">
                    <h4>Bookings List</h4>
                     ${filterbtn}

            
                    <div class="list-product">
                     <a class="btn btn-primary" href="#" onclick="refreshlist()">Refresh</a>
                        <a class="btn btn-danger" href="#" onclick="UpdateCheckStatus(-2)">Decline</a>
                        <a class="btn btn-success" href="#"  onclick="UpdateCheckStatus(5)">Approve</a>

                    </div>
                    <div class="asset-inner">
                        <table>
                            <tr>
                                <th>#</th>
                            
                                <th>RouteCode</th>
                                <th>Names</th>
                                <th>Booked ON</th>
                                <th>Booking Reason</th>
                                <th>City/Town</th>
                                <th >Status</th>
                                <th>Cost</th>
                                <th># of Nights</th>
                                <th>Paid</th>

                            </tr>
                           
                          
                            ${output}
                          
                        </table>
                    </div>
                    <div class="custom-pagination">
                        <ul class="pagination">
                            <li class="page-item"><a class="page-link" href="#">Previous</a></li>
                            <li class="page-item"><a class="page-link" href="#">1</a></li>
                            <li class="page-item"><a class="page-link" href="#">2</a></li>
                            <li class="page-item"><a class="page-link" href="#">3</a></li>
                            <li class="page-item"><a class="page-link" href="#">Next</a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
    </div>`

    $("#calenderViewHtml").slideUp()

    $("#HTML_Loader").html('')
    $("#HTML_Loader").html(BookingList)
}


function refreshlist(){
    globaldata=JSON.parse( sessionStorage.getItem("bookings"))
    Listbookings()
}

function postbooking(){
    var bookingObj={}
    var e=false
    var t=false
    var s=false;
    var d=false
    $(".fa").remove()
    for(var i=0;i<inputsEmployee.length;i++){
        ch=$("#"+inputsEmployee[i]).val()
        if( $("#"+inputsEmployee[i]).val()!==''  && $("#"+inputsEmployee[i]).val()!=="default" ){
            bookingObj[inputsEmployee[i]]=$("#"+inputsEmployee[i]).val()

        }else{

            $("#actEmployee").append('<i class="fa fa-times" style="color:red" aria-hidden="true"></i>');
            e=true;

        }



    }
    for(var i=0;i<InputBookingType.length;i++){
        if( $("#"+InputBookingType[i]).val()!==''  && $("#"+InputBookingType[i]).val()!=="default" ){
            bookingObj[InputBookingType[i]]=$("#"+InputBookingType[i]).val()


        }else{

            $("#actBookingTypes").append('<i class="fa fa-times" style="color:red" aria-hidden="true"></i>');
                t=true
        }

    }
    for(var i=0;i<inputBookingdates.length;i++){
        if( $("#"+inputBookingdates[i]).val()!==''  && $("#"+inputBookingdates[i]).val()!=="default" ){
            bookingObj[inputBookingdates[i]]=$("#"+inputBookingdates[i]).val()



        }else{

            $("#actDates").append('<i class="fa fa-times" style="color:red" aria-hidden="true"></i>');
                d=true
        }


    }


    for(var i=0;i<inputSupplierDetails.length;i++){
        if($("#"+inputSupplierDetails[i]).val()!==''  && $("#"+inputSupplierDetails[i]).val()!=="default" ){
            bookingObj[inputSupplierDetails[i]]=$("#"+inputSupplierDetails[i]).val()

        }else{

            $("#actSupplier").append('<i class="fa fa-times" style="color:red" aria-hidden="true"></i>');
                s=true
        }


    }

    if(s==false && d==false && e==false && t==false){
    bookingObj["Created"]=sessionStorage.getItem("UserID")
    bookingObj["Notes"]=null
    bookingObj["POnumber"]=null
    bookingObj["SupplierInvoice"]=null
    bookingObj["DatePaid"]=null
    bookingObj["AmountPaid"]=null
    
    var s=sessionStorage.getItem('SessionToken')
    var id=sessionStorage.getItem("UserID")
    var headers={}
    headers["SessionToken"]=s;
    headers["UserID"]=id;
    $("#HTML_Loader").html('')
    $("#HTML_Loader").html("<img src='img/loading.gif' style='margin-left:50%' width=180/>")
    $.ajax({
        url:`https://kanibaapp.azurewebsites.net/BackEnd/BookingRequest`,
        type: 'POST',
        datatype: 'json',
        data:bookingObj,
        cache: false,
        headers:headers,
        success: function(rdata) {
            handlebookingInsert(rdata);
        }
    });
}
}

function handlebookingInsert(res){
    if(res.Success==true){

        $("#HTML_Loader").html('')
        $("#HTML_Loader").html("<img src='img/R.gif' style='margin-left:50%'  width=180/>")
    }else{

        $("#HTML_Loader").html('')
        $("#HTML_Loader").html("<img src='img/OIP.jpeg' style='margin-left:50%' width=180/>")

    }
}
function createColorFirStatuys(st){
    switch(st){
        case -3:
        return "#FF5733"
        break;
         case -2: 
         return "#B03A2E"
         break;
          case -1: 
          return "#E74C3C"
          break;
          case 0:
          return "#F4D03F"
          break;
           case 1:
           return "#85C1E9"
           break;
            case 2: 
            return "#F4D03F"
            break;
            case 3: 
            return "#B7950B"
            break;
             case 4: 
             return "#F5B041"
             break;
             case 5:
             return "#ABEBC6"
             break;
             case 6:
             return "#8E44AD"
             break;
             case 7: 
             return "#52BE80"
             break;
             case 8: 
             return "#F458FF"
             break;
             case 9: 
             return "#04ABAB"
             break;
             case 10: 
             return "#FE84F3"
             break;
              default:
              return "#17202A"
              break;
    }
}

function Checkpaid(p){
    if(p!=null){
        return p;
    }else{
        return "Not paid"
    }
}



function BookingDetails(idx){

b=sessionStorage.getItem("bookings")
    bookingData=JSON.parse(b)["Dt"][idx];
    team=JSON.parse(sessionStorage.getItem("team"))
    Fullnames=''
    Email=''
    Contact=''
    Client=''
    ProfileImage=''
    for(var i =0 ;i<team.length;i++){
        if(team[i]["RouteCode"]==bookingData["RouteCode"]){ 
            Fullnames=team[i]["FullName"]
            Email=team[i]["email"]
            Contact=000000000
            ProfileImage=team[i]["ProfileImage"]

        }
    }
`
    case -3: return "BSS On leave" 
    case -2: return "Declined" 
    case -1: return "Cancelled"
     case 0: return "Pending" 
     case 1: return "BSS Accepted" 
    case 2: return "Pending PO"
     case 3: return "Pending Supervisor pre. approval" 
     case 10 : Supervisor Pre-approved
    case 4: return "Pending POP"
    case 8 : Pending Supervisor approval"
     case 5: return "Approved" 
     case 6: return "BSS checked in"
     case 7: return "Completed"
     case 9: BSS checked out
      default: return "Unknown"`
var btnBSSbooking=''
var ID=bookingData.ID
    switch(sessionStorage.getItem("UserType")){
        case "BSS":
        switch(bookingData.Status){
            case 0:
               btnBSSbooking=` <Button type='button' onclick="UpdateCheckStatus(1,${ID})" class='btn btn-primary'>Accept a booking</Button>
                <Button type='button' onclick="UpdateCheckStatus(-2,${ID})" class='btn btn-primary'>Decline a booking</Button>
                <Button type='button' onclick="UpdateCheckStatus(-3,${ID})"  class='btn btn-primary'>Currently on Leave</Button>`
                break;
            case 5:
                btnBSSbooking=`  <Button type='button' onclick="UpdateCheckStatus(6,${ID})"  class='btn btn-primary'>Check in</Button>
                <Button type='button' onclick="UpdateCheckStatus(-1,${ID})"  class='btn btn-primary'>Cancel the booking</Button>`
                break;
            case 6:
                btnBSSbooking="<Button type='button' onclick='UpdateCheckStatus(9,"+ID+")'  class='btn btn-primary'>Check out</Button>"
        }
        break;
        case "ASM":
           switch(bookingData.Status){
             case 3:
                btnBSSbooking="<Button type='button' onclick='UpdateCheckStatus(10,"+ID+")'  class='btn btn-primary'>Pre-Approve</Button>"
                break;
                case 8:
               btnBSSbooking="<Button onclick='UpdateCheckStatus(5,"+ID+")'  type='button' class='btn btn-primary'>Approve</Button>"
                 break;
           }
        case "Manager":
            switch(bookingData.Status){
                case 9:
                   btnBSSbooking="<Button type='button' onclick='UpdateCheckStatus(7,"+ID+")'  class='btn btn-primary'>Complete</Button>"
                   break;
              }
        case "BackOffice":
            switch(bookingData.Status){
                case 1:
                   btnBSSbooking="<Button type='button' onclick='AddAttachement('PO',"+ID+")'  class='btn btn-primary'>Attach a PO</Button>"
                   break;
                case 10:
                  btnBSSbooking="<Button type='button' onclick='AddAttachement('POP',"+ID+")'  class='btn btn-primary'>Attach POP</Button>"
                    break;
                case 9:
                   btnBSSbooking="<Button type='button' onclick='UpdateCheckStatus(7,"+ID+")' class='btn btn-primary'>Complete</Button>"
                   break;
              }

    }

list_asm_fm_booking=`<div class="single-pro-review-area mt-t-30 mg-b-15">
<div class="container-fluid">
    <div class="row">
    <button type="button" onclick="Listbookings()"class="backtopbtn">Back</button>
        <div class="col-lg-4 col-md-4 col-sm-4 col-xs-12">
            <div class="profile-info-inner">
                <div class="profile-img" id="profile-img-booking">
                    <img id="profilebooking" width=30 alt="" />
                </div>
                <div class="profile-details-hr">
                    <div class="row">
                        <div class="col-lg-6 col-md-12 col-sm-12 col-xs-6">
                            <div class="address-hr">
                                <p><b>Name</b><br /> ${Fullnames}</p>
                            </div>
                        </div>
                        <div class="col-lg-6 col-md-12 col-sm-12 col-xs-6">
                            <div class="address-hr tb-sm-res-d-n dps-tb-ntn">
                                <p><b>RouteCode</b><br /> ${bookingData["RouteCode"]}</p>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-lg-6 col-md-12 col-sm-12 col-xs-6">
                            <div class="address-hr">
                                <p><b>Email ID</b><br /> ${Email}</p>
                            </div>
                        </div>
                        <div class="col-lg-6 col-md-12 col-sm-12 col-xs-6">
                            <div class="address-hr tb-sm-res-d-n dps-tb-ntn">
                                <p><b>Phone</b><br /> +${Contact}</p>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-lg-12">
                            <div class="address-hr">
                                <p><b>Traveling To </b><br /> ${bookingData["CityTown"]}</p>
                            </div>
                            <div class="address-hr" style="background-color:${createColorFirStatuys(bookingData["Status"])}">
                            <p><b>Current Status</b><br /> ${bookingData["Description"]}</p>
                          
                        </div>
                        </div>
                    </div>
                   <div  > ${btnBSSbooking} </div>
                    <div class="row" style="border-top:2px solid black">
                        <div class="col-lg-4 col-md-4 col-sm-4 col-xs-4">
                            <div class="address-hr">
                                <p>Total Cost</p>
                                <p>R${bookingData["Total payable inc VAT"]}</p>
                            </div>
                        </div>
                        <div class="col-lg-4 col-md-4 col-sm-4 col-xs-4">
                            <div class="address-hr">
                                <p>Number of Nights</p>
                                <p>${bookingData["No of Nights"]} 
                                </p>
                            </div>
                        </div>
                        <div class="col-lg-4 col-md-4 col-sm-4 col-xs-4">
                            <div class="address-hr">
                                <p>Dinner included</p>
                                <p>${CheckifDinnerIncluded(bookingData["Dinner included"])}</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-lg-8 col-md-8 col-sm-8 col-xs-12">
            <div class="product-payment-inner-st res-mg-t-30 analysis-progrebar-ctn">
                <ul id="myTabedu1" class="tab-review-design">
                    <li class="active activeTab" id="Cactivity"><a onclick="showDivBooking('activity')" href="#">Activity</a></li>
                    <li class="activeTab" id="CDates"><a onclick="showDivBooking('Dates')" href="#"> Booking dates</a></li>
                    <li class="activeTab" id="CSupplier"><a onclick="showDivBooking('Supplier')" href="#">Supplier infomation</a></li>
                    <li class="activeTab" id="CBookingTypes"><a onclick="showDivBooking('BookingTypes')" href="#">Booking Type</a></li>
                    <li class="activeTab" id="CInvoices"><a onclick="showDivBooking('Invoices')" href="#">Invoices</a></li>
                </ul>
                <span id='showMyDivHtml'></span>
            </div>
        </div>
    </div>
</div>
</div>`
$("#calenderViewHtml").slideUp()
$("#HTML_Loader").html('')
$("#HTML_Loader").html(list_asm_fm_booking)

$("#profilebooking").attr("src",ProfileImage)

createDatatables(bookingData,InputBookingType,"BookingTypes")
createDatatables(bookingData,GetinputSupplierDetails,"Supplier")
createDatatables(bookingData,GetinputBookingdates,"Dates")
createDatatables(bookingData,GetInputInvoices,"Invoices")

ShowActivities(bookingData.ID)

$("#BookingTypes").slideUp()
$("#Supplier").slideUp()
$("#Dates").slideUp()
$("#Invoices").slideUp()



}

function ShowActivities(id){
    $.ajax({
        url:`https://kanibaapp.azurewebsites.net/BackEnd/GetActivityByBookingID?bookingID=${id}`,
        type: 'GET',
        datatype: 'json',
        cache: false,
        success: function(rdata) {
            putActivityInatimeline(rdata);
        }
    });
}

function putActivityInatimeline(data){
  
    
    showDivBooking("activity")
    
var text=''
data["Dt"].sort(function(a, b) {
    return new Date (b.Date) - new Date(a.Date);
    });

for(var i=0; i<data["Dt"].length; i++){
        text+=`<div class="chat-message">
        <div class="message" >
            <a class="message-author" href="#"> ${data["Dt"][i]["UpdatedBy"]} </a>
            <span class="message-date"> ${data["Dt"][i]["Date"]} </span>
            <span class="message-content">
               Status changed to ${data["Dt"][i]["Status"]}                     </span>

                <a class="btn btn-xs btn-primary"><i class="fa fa-pencil"></i> Message</a>
            </div>
       
    </div>`
}
    var htmlBooki=`<div id="myTabContent" class="tab-content custom-product-edit" id="activityremove">
<div class="product-tab-list tab-pane fade active in" id="description">
    <div class="row" id="activity">
        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
            <div class="review-content-section">
                <div class="chat-discussion" style="height: auto">
                    <div class="chat-message" >
                                          
                            ${text}
    
                    </div>

                   
                    </div>

                </div>
            </div>
        </div>
    </div>
</div>

</div>`

$("#showMyDivHtml").append(htmlBooki)
}

function createDatatables(bdata,data,elem){
    var htmlElem=''
    for(var i=0; i<data.length; i++){
        htmlElem+=`<tr><td>${data[i]}</td><td>${bdata[data[i]]}</td></tr>`
    }

    var htmlBooking=`<div id="myTabContent" class="tab-content custom-product-edit">
    <div class="product-tab-list tab-pane fade active in" id="description">
        <div class="row" >
            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                <div class="review-content-section">
                    <div class="chat-discussion" style="height: auto">
                        <div class="chat-message">
                           
                            <div class="message" id="${elem}">
                            <table class="table table-hover" >
                                ${htmlElem}

                            </table>
                            </div>
                        </div>

                       
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </div>

</div>`

$("#showMyDivHtml").append(htmlBooking)

}
function CheckifDinnerIncluded(d){
    if(d==1){
        return "Yes"
    }else{
        return "No"
    }
}

function showDivBooking(elem){
$("#BookingTypes").slideUp()

$("#activity").slideUp()

$("#Supplier").slideUp()
$("#Dates").slideUp()
$("#Invoices").slideUp()
$("#"+elem).slideDown()
$(".activeTab").removeClass("active")
$("#C"+elem).addClass("active")
}

function createselect(elem){
    data=JSON.parse( sessionStorage.getItem("team"));
    output="<select id="+elem+" onchange='onchageselect()'><option value='default' selected>Choose a BSS</option>"
    for(var i=0;i<data.length;i++){
        output+="<option value="+data[i]["RouteCode"]+">"+data[i]["RouteCode"]+"</option>"
    }
    output+="</select>"
    return output;
}

function onchageselect(){
    team=JSON.parse( sessionStorage.getItem("team"));
    img=''
    for(var k =0; k<team.length; k++){
        if(team[k]["RouteCode"]==$("#RouteCode").val()){
            for(var i=0;i<inputsEmployee.length;i++){
                $("#Email").val(team[k]["email"])
                var slpt=team[k]["FullName"].split(" ")
                $("#Surname").val(slpt[slpt.length-1])
                $("#Name").val(slpt[0])
                img=team[k]["ProfileImage"]

            }
        }
        
        
    }
    $(".imgBookingView").remove()
    $("#PutbookingImage").append("<div class='imgBookingView'><img src="+img+"/></div>")

}